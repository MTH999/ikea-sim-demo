# IKEA Sustainability Executive Simulator (Demo)

A minimal React + Vite + TypeScript demo using your game logic and panels.

## Quick start

```bash
npm install
npm run dev
```

Then open the URL printed by Vite (usually http://localhost:5173).

## What’s included
- React + TypeScript + Vite
- Your `useGameState` hook (with metrics history)
- Metrics panel with trends
- Simple investment panel
- Quarterly progress & feedback
- Outcome screen with final scores

## Notes
- No Tailwind/shadcn required; components use inline styles for simplicity.
- You can later swap the UI components for your Tailwind/shadcn versions.

## Scripts
- `npm run dev` — start dev server
- `npm run build` — production build
- `npm run preview` — preview the built app

