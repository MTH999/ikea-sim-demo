import { useState, useCallback } from 'react';

export interface GameMetrics {
  cash: number;
  co2Emissions: number;
  waste: number;
  materialCosts: number;
  reputation: number;
}

export interface Investment {
  type: 'production' | 'supply' | 'mitigation';
  name: string;
  quarter: number;
  cost?: number;
}

interface GameState {
  currentQuarter: number;
  metrics: GameMetrics;
  investments: Investment[];
  quarterlyChanges: {
    quarter: number;
    changes: string[];
  }[];
  metricsHistory: GameMetrics[];
}

const INITIAL_METRICS: GameMetrics = {
  cash: 500000,
  co2Emissions: 850,
  waste: 1200,
  materialCosts: 180000,
  reputation: 75,
};

export const useGameState = () => {
  const [gameState, setGameState] = useState<GameState>({
    currentQuarter: 1,
    metrics: { ...INITIAL_METRICS },
    investments: [],
    quarterlyChanges: [],
    metricsHistory: [{ ...INITIAL_METRICS }],
  });

  const makeInvestment = useCallback((type: 'production' | 'supply' | 'mitigation', name: string, cost: number) => {
    setGameState((prev) => {
      const newMetrics = { ...prev.metrics };
      newMetrics.cash -= cost;

      return {
        ...prev,
        metrics: newMetrics,
        investments: [...prev.investments, { type, name, quarter: prev.currentQuarter, cost }],
      };
    });
  }, []);

  const advanceQuarter = useCallback(() => {
    setGameState((prev) => {
      const newMetrics = { ...prev.metrics };
      const changes: string[] = [];

      const currentQuarterInvestments = prev.investments.filter(
        (inv) => inv.quarter === prev.currentQuarter
      );

      currentQuarterInvestments.forEach((inv) => {
        if (inv.type === 'production') {
          if (inv.name === 'Basic Production Upgrade') {
            newMetrics.co2Emissions -= 35;
            newMetrics.waste -= 60;
            newMetrics.materialCosts -= 12000;
            newMetrics.reputation += 3;
            changes.push(`${inv.name}: Production costs decreased by €12,000, CO₂ emissions reduced by 4%, waste reduced by 5%.`);
          } else if (inv.name === 'Advanced Automation') {
            newMetrics.co2Emissions -= 95;
            newMetrics.waste -= 150;
            newMetrics.materialCosts -= 35000;
            newMetrics.reputation += 12;
            changes.push(`${inv.name}: Major efficiency gains! Production costs slashed by €35,000, CO₂ emissions reduced by 11%, waste reduced by 12%.`);
          } else if (inv.name === 'Green Innovation Fund') {
            newMetrics.co2Emissions -= Math.round(newMetrics.co2Emissions * 0.12);
            newMetrics.waste -= Math.round(newMetrics.waste * 0.08);
            newMetrics.materialCosts -= 10000;
            newMetrics.reputation += 15;
            changes.push(`${inv.name}: CO₂ reduced by 12%, waste down by 8%, operational savings €10,000, reputation +15.`);
          }
        } else if (inv.type === 'supply') {
          if (inv.name === 'Local Sourcing Initiative') {
            newMetrics.co2Emissions -= 80;
            newMetrics.materialCosts += 6000;
            newMetrics.reputation += 6;
            changes.push(`${inv.name}: CO₂ emissions reduced by 9% through local partnerships, but material costs increased by €6,000. Community relations improved.`);
          } else if (inv.name === 'Sustainable Materials Program') {
            newMetrics.co2Emissions -= 170;
            newMetrics.materialCosts += 25000;
            newMetrics.reputation += 20;
            changes.push(`${inv.name}: Revolutionary impact! CO₂ emissions slashed by 20%, brand reputation soared. Material costs increased by €25,000 but customer loyalty is at an all-time high.`);
          }
        } else if (inv.type === 'mitigation') {
          if (inv.name === 'Waste Reduction System') {
            newMetrics.co2Emissions -= 40;
            newMetrics.waste -= 120;
            newMetrics.materialCosts -= 8000;
            newMetrics.reputation += 5;
            changes.push(`${inv.name}: Waste reduced by 10%, CO₂ emissions decreased by 5%. Material reuse saved €8,000.`);
          } else if (inv.name === 'Carbon Capture Tech') {
            newMetrics.co2Emissions -= 200;
            newMetrics.waste -= 250;
            newMetrics.materialCosts -= 15000;
            newMetrics.reputation += 18;
            changes.push(`${inv.name}: Game-changing technology! CO₂ emissions plummeted by 23%, waste management revolutionized (-21%). Operational savings of €15,000 plus massive reputation boost.`);
          }
        }
      });

      if (currentQuarterInvestments.length === 0) {
        changes.push('No investments made - operations continued as usual with minimal efficiency gains.');
        newMetrics.co2Emissions += 20;
        newMetrics.waste += 30;
      }

      const revenueBonus = Math.floor(newMetrics.reputation / 10) * 5000;
      newMetrics.cash += 120000 + revenueBonus;
      changes.push(`Quarterly revenue: €${(120000 + revenueBonus).toLocaleString()} (base + reputation bonus).`);

      const clamped = {
        cash: Math.max(0, Math.round(newMetrics.cash)),
        co2Emissions: Math.max(0, Math.round(newMetrics.co2Emissions)),
        waste: Math.max(0, Math.round(newMetrics.waste)),
        materialCosts: Math.max(0, Math.round(newMetrics.materialCosts)),
        reputation: Math.min(100, Math.max(0, Math.round(newMetrics.reputation))),
      };

      return {
        ...prev,
        currentQuarter: prev.currentQuarter + 1,
        metrics: clamped,
        quarterlyChanges: [
          ...prev.quarterlyChanges,
          { quarter: prev.currentQuarter, changes },
        ],
        metricsHistory: [...prev.metricsHistory, clamped],
      };
    });
  }, []);

  const calculateFinalScores = useCallback(() => {
    const metrics = gameState.metrics;

    const profitScore = Math.min(100, Math.max(0, metrics.cash / 10000));

    const co2Reduction = ((INITIAL_METRICS.co2Emissions - metrics.co2Emissions) / INITIAL_METRICS.co2Emissions) * 100;
    const co2Score = Math.min(100, Math.max(0, 50 + co2Reduction));

    const wasteReduction = ((INITIAL_METRICS.waste - metrics.waste) / INITIAL_METRICS.waste) * 100;
    const circularityScore = Math.min(100, Math.max(0, 50 + wasteReduction + (metrics.reputation - 75) / 2));

    const overallScore = (profitScore + co2Score + circularityScore) / 3;

    return {
      profit: Math.round(profitScore),
      co2: Math.round(co2Score),
      circularity: Math.round(circularityScore),
      overall: Math.round(overallScore),
    };
  }, [gameState.metrics]);

  const resetGame = useCallback(() => {
    setGameState({
      currentQuarter: 1,
      metrics: { ...INITIAL_METRICS },
      investments: [],
      quarterlyChanges: [],
      metricsHistory: [{ ...INITIAL_METRICS }],
    });
  }, []);

  return {
    gameState,
    makeInvestment,
    advanceQuarter,
    calculateFinalScores,
    resetGame,
  };
};
