import React from 'react';

export const Card = ({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) => (
  <div
    style={{
      padding: 12,
      borderRadius: 12,
      border: '1px solid #ddd',
      background: '#fff',
      boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
      ...style,
    }}
  >
    {children}
  </div>
);
