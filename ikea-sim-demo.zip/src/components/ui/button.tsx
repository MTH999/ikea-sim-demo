import React from 'react';

export const Button = ({ children, onClick, disabled, title, style }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button
    onClick={onClick}
    disabled={disabled}
    title={title}
    style={{
      padding: '10px 16px',
      borderRadius: 8,
      border: '1px solid #0ea5e9',
      background: disabled ? '#e5e7eb' : '#0ea5e9',
      color: '#fff',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontWeight: 600,
      ...style,
    }}
  >
    {children}
  </button>
);
