import { GameMetrics } from '../hooks/useGameState';

interface MetricsPanelProps {
  metrics: GameMetrics;
  previous?: GameMetrics;
}

export const MetricsPanel = ({ metrics, previous }: MetricsPanelProps) => {
  const diff = {
    cash: previous ? metrics.cash - previous.cash : 0,
    co2: previous ? metrics.co2Emissions - previous.co2Emissions : 0,
    waste: previous ? metrics.waste - previous.waste : 0,
    mat: previous ? metrics.materialCosts - previous.materialCosts : 0,
    rep: previous ? metrics.reputation - previous.reputation : 0,
  };

  return (
    <div style={{ marginBottom: 16 }}>
      <h2 style={{ marginBottom: 8 }}>Sustainability Dashboard</h2>
      <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'repeat(5, minmax(0,1fr))' }}>
        <Metric label="Cash" value={`€${Math.round(metrics.cash / 1000)}K`} helper={previous ? formatDiffEuro(diff.cash) : undefined} />
        <Metric label="CO₂" value={`${metrics.co2Emissions} tons`} helper={previous ? formatDiff(diff.co2, 'tons') : undefined} />
        <Metric label="Waste" value={`${metrics.waste} kg`} helper={previous ? formatDiff(diff.waste, 'kg') : undefined} />
        <Metric label="Material Costs" value={`€${Math.round(metrics.materialCosts / 1000)}K`} helper={previous ? formatDiffEuro(diff.mat) : undefined} />
        <Metric label="Reputation" value={`${metrics.reputation}%`} helper={previous ? formatDiff(diff.rep, 'pts') : undefined} />
      </div>
    </div>
  );
};

const Metric = ({ label, value, helper }: { label: string; value: string; helper?: string }) => (
  <div style={{ padding: 12, border: '1px solid #ddd', borderRadius: 8, background: '#fff' }}>
    <div style={{ color: '#666', fontSize: 12 }}>{label}</div>
    <div style={{ fontWeight: 700, fontSize: 20 }}>{value}</div>
    {helper && <div style={{ color: '#666', fontSize: 12 }}>{helper}</div>}
  </div>
);

const formatDiff = (n: number, unit: string) => `${n > 0 ? '+' : n < 0 ? '−' : '±'} ${Math.abs(Math.round(n))} ${unit}`;
const formatDiffEuro = (n: number) => `${n > 0 ? '+' : n < 0 ? '−' : '±'} €${Math.abs(n).toLocaleString()}`;
