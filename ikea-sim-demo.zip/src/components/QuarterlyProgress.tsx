export const QuarterlyProgress = ({ currentQuarter }: { currentQuarter: number }) => {
  return (
    <div style={{ margin: '16px 0', padding: 12, border: '1px solid #ddd', borderRadius: 8, background: '#fff' }}>
      <strong>Quarter:</strong> {currentQuarter} / 4
    </div>
  );
};
