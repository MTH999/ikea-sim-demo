import { Button } from './ui/button';
import { GameMetrics } from '../hooks/useGameState';

export const OutcomePanel = ({
  scores,
  finalMetrics,
  totalInvestments,
  onStartAgain,
}: {
  scores: { profit: number; co2: number; circularity: number; overall: number };
  finalMetrics: GameMetrics;
  totalInvestments: number;
  onStartAgain: () => void;
}) => {
  return (
    <div style={{ maxWidth: 640, margin: '0 auto', border: '1px solid #ddd', borderRadius: 12, padding: 16, background: '#fff' }}>
      <h2 style={{ marginTop: 0 }}>Final Outcome</h2>
      <p>Total investments: {totalInvestments}</p>
      <ul>
        <li>Profit Score: {scores.profit}</li>
        <li>CO₂ Score: {scores.co2}</li>
        <li>Circularity Score: {scores.circularity}</li>
        <li><strong>Overall Score: {scores.overall}</strong></li>
      </ul>
      <h3>Final Metrics</h3>
      <ul>
        <li>Cash: €{finalMetrics.cash.toLocaleString()}</li>
        <li>CO₂: {finalMetrics.co2Emissions} tons</li>
        <li>Waste: {finalMetrics.waste} kg</li>
        <li>Material Costs: €{finalMetrics.materialCosts.toLocaleString()}</li>
        <li>Reputation: {finalMetrics.reputation}%</li>
      </ul>
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 16 }}>
        <Button onClick={onStartAgain}>Start Again</Button>
      </div>
    </div>
  );
};
