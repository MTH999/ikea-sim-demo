import { Button } from './ui/button';

export const InvestmentPanel = ({
  availableCash,
  onInvest,
}: {
  availableCash: number;
  onInvest: (type: 'production' | 'supply' | 'mitigation', name: string, cost: number) => void;
}) => {
  const catalog: { type: 'production' | 'supply' | 'mitigation'; name: string; cost: number }[] = [
    { type: 'production', name: 'Basic Production Upgrade', cost: 50000 },
    { type: 'production', name: 'Advanced Automation', cost: 120000 },
    { type: 'production', name: 'Green Innovation Fund', cost: 100000 },
    { type: 'supply', name: 'Local Sourcing Initiative', cost: 40000 },
    { type: 'supply', name: 'Sustainable Materials Program', cost: 90000 },
    { type: 'mitigation', name: 'Waste Reduction System', cost: 35000 },
    { type: 'mitigation', name: 'Carbon Capture Tech', cost: 200000 },
  ];

  return (
    <div style={{ marginBottom: 16 }}>
      <h3>Investments</h3>
      <div style={{ display: 'grid', gap: 8, gridTemplateColumns: 'repeat(2, minmax(0,1fr))' }}>
        {catalog.map((item) => {
          const afford = availableCash >= item.cost;
          return (
            <div key={item.name} style={{ border: '1px solid #ddd', borderRadius: 8, padding: 12 }}>
              <div style={{ fontWeight: 600 }}>{item.name}</div>
              <div style={{ color: '#666' }}>
                Type: {item.type} · Cost: €{item.cost.toLocaleString()}
              </div>
              <Button
                style={{ marginTop: 8 }}
                disabled={!afford}
                title={afford ? '' : 'Not enough cash'}
                onClick={() => onInvest(item.type, item.name, item.cost)}
              >
                Invest
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
