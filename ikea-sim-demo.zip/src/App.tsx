import { useState, useEffect } from 'react';
import { Building2 } from 'lucide-react';
import { Button } from './components/ui/button';
import { useGameState } from './hooks/useGameState';
import { MetricsPanel } from './components/MetricsPanel';
import { InvestmentPanel } from './components/InvestmentPanel';
import { QuarterlyProgress } from './components/QuarterlyProgress';
import { OutcomePanel } from './components/OutcomePanel';

const App = () => {
  const { gameState, makeInvestment, advanceQuarter, calculateFinalScores, resetGame } = useGameState();
  const [phase, setPhase] = useState<'playing' | 'finished'>('playing');
  const [showFeedback, setShowFeedback] = useState(false);

  useEffect(() => {
    if (gameState.currentQuarter > 4) {
      setPhase('finished');
    } else if (gameState.currentQuarter > 1) {
      setShowFeedback(true);
    }
  }, [gameState.currentQuarter]);

  const handleEndQuarter = () => {
    advanceQuarter();
  };

  const handleStartAgain = () => {
    resetGame();
    setPhase('playing');
    setShowFeedback(false);
  };

  const lastQuarterChanges = gameState.quarterlyChanges[gameState.quarterlyChanges.length - 1];

  return (
    <div style={{ minHeight: '100vh', padding: 24, background: 'linear-gradient(135deg,#f6f9fc,#eef7f0,#f3f7ff)' }}>
      <header style={{ textAlign: 'center', marginBottom: 24 }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
          <Building2 size={48} color="#0ea5e9" />
          <h1 style={{ fontSize: 32, margin: 0 }}>IKEA Sustainability Executive Simulator</h1>
        </div>
        <p style={{ color: '#666' }}>Manage factories, reduce emissions, and grow sustainably! 🌱</p>
      </header>

      {phase === 'playing' ? (
        <>
          <MetricsPanel
            metrics={gameState.metrics}
            previous={gameState.metricsHistory?.[gameState.metricsHistory.length - 2]}
          />

          <InvestmentPanel
            availableCash={gameState.metrics.cash}
            onInvest={makeInvestment}
          />

          <QuarterlyProgress currentQuarter={gameState.currentQuarter} />

          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 16 }}>
            <Button onClick={handleEndQuarter}>🎯 End Quarter & See Results</Button>
          </div>

          {showFeedback && lastQuarterChanges && (
            <div style={{ marginTop: 24, padding: 16, border: '1px solid #cfe3ff', borderRadius: 8, background: '#f7fbff' }}>
              <h3 style={{ marginTop: 0 }}>Quarter {lastQuarterChanges.quarter} Results</h3>
              <ul>
                {lastQuarterChanges.changes.map((c, i) => (
                  <li key={i}>{c}</li>
                ))}
              </ul>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button onClick={() => setShowFeedback(false)}>Continue</Button>
              </div>
            </div>
          )}
        </>
      ) : (
        <OutcomePanel
          scores={calculateFinalScores()}
          finalMetrics={gameState.metrics}
          totalInvestments={gameState.investments.length}
          onStartAgain={handleStartAgain}
        />
      )}

      <footer style={{ textAlign: 'center', marginTop: 32, color: '#666' }}>
        <p>Make strategic decisions to build a sustainable future! 🌍</p>
      </footer>
    </div>
  );
};

export default App;
